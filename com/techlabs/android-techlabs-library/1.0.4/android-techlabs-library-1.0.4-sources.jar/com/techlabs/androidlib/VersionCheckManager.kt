package com.techlabs.androidlib

import com.techlabs.androidlib.model.VersionCheckInfo
import com.techlabs.androidlib.model.VersionCheckResult

/**
 * 버전 체크 오케스트레이션 매니저.
 * Flutter 원본의 getAppVerChk() 로직을 네이티브로 이식한 것이다.
 */
class VersionCheckManager {

    companion object {
        private const val UPDATE_TYPE_FORCE = "0"
        private const val UPDATE_TYPE_OPTIONAL = "1"
    }

    /**
     * Android용: 빌드넘버(int) 기반 버전 체크.
     *
     * @param info 서버 응답 정보 (null이면 Error 반환)
     * @param currentBuildNumber 현재 앱의 빌드넘버
     */
    fun checkVersion(info: VersionCheckInfo?, currentBuildNumber: Int): VersionCheckResult {
        if (info == null) return VersionCheckResult.Error

        if (info.ver.isEmpty()) return VersionCheckResult.NoUpdateNeeded

        val serverBuildNumber = info.ver.toIntOrNull() ?: return VersionCheckResult.NoUpdateNeeded
        val isUpdateRequired = VersionComparator.isUpdateRequired(serverBuildNumber, currentBuildNumber)

        return resolveResult(isUpdateRequired, info)
    }

    /**
     * iOS용: 문자열 버전(x.y.z) 기반 버전 체크.
     *
     * @param info 서버 응답 정보 (null이면 Error 반환)
     * @param currentVersion 현재 앱의 버전 문자열 (예: "8.4.5")
     */
    fun checkVersion(info: VersionCheckInfo?, currentVersion: String): VersionCheckResult {
        if (info == null) return VersionCheckResult.Error

        if (info.ver.isEmpty()) return VersionCheckResult.NoUpdateNeeded

        val isUpdateRequired = VersionComparator.isUpdateRequired(info.ver, currentVersion)

        return resolveResult(isUpdateRequired, info)
    }

    /**
     * Flutter MethodChannel에서 직접 사용 가능한 Map 기반 버전 체크.
     *
     * @param infoMap 서버 응답 데이터 Map (null이면 Error 반환)
     * @param currentBuildNumber 현재 앱의 빌드넘버 (Android)
     */
    fun checkVersion(infoMap: Map<String, Any?>?, currentBuildNumber: Int): VersionCheckResult {
        if (infoMap == null) return VersionCheckResult.Error
        val info = VersionCheckInfo.fromMap(infoMap)
        return checkVersion(info, currentBuildNumber)
    }

    /**
     * Flutter MethodChannel에서 직접 사용 가능한 Map 기반 버전 체크.
     *
     * @param infoMap 서버 응답 데이터 Map (null이면 Error 반환)
     * @param currentVersion 현재 앱의 버전 문자열 (iOS)
     */
    fun checkVersion(infoMap: Map<String, Any?>?, currentVersion: String): VersionCheckResult {
        if (infoMap == null) return VersionCheckResult.Error
        val info = VersionCheckInfo.fromMap(infoMap)
        return checkVersion(info, currentVersion)
    }

    private fun resolveResult(isUpdateRequired: Boolean, info: VersionCheckInfo): VersionCheckResult {
        if (!isUpdateRequired) return VersionCheckResult.NoUpdateNeeded

        val type = info.type.ifEmpty { "0" }
        return when (type) {
            UPDATE_TYPE_FORCE -> VersionCheckResult.ForceUpdate(info.appName2)
            UPDATE_TYPE_OPTIONAL -> VersionCheckResult.OptionalUpdate(info.appName2)
            else -> VersionCheckResult.ForceUpdate(info.appName2)
        }
    }
}
