package com.techlabs.androidlib

import com.techlabs.androidlib.model.NoticeCheckInfo
import com.techlabs.androidlib.model.NoticeCheckResult

/**
 * 공지사항 체크 오케스트레이션 매니저.
 * Flutter 원본의 checkNoticeNew() 로직을 네이티브로 이식한 것이다.
 */
class NoticeCheckManager {

    /**
     * 공지사항 체크: 서버의 최신 공지 인덱스와 사용자가 마지막으로 본 인덱스를 비교한다.
     *
     * @param info 서버 응답 정보 (null이면 Error 반환)
     * @param lastSeenIndex 사용자가 마지막으로 본 공지 인덱스 (SharedPreference의 notice_last_idx2)
     */
    fun checkNotice(info: NoticeCheckInfo?, lastSeenIndex: Int): NoticeCheckResult {
        if (info == null) return NoticeCheckResult.Error

        val serverIndex = info.ntcLastIdx.toIntOrNull()
        if (info.ntcLastIdx.isEmpty() || serverIndex == null) {
            return NoticeCheckResult.NoNewNotice
        }

        return if (serverIndex > lastSeenIndex) {
            NoticeCheckResult.HasNewNotice(serverIndex)
        } else {
            NoticeCheckResult.NoNewNotice
        }
    }

    /**
     * Flutter MethodChannel에서 직접 사용 가능한 Map 기반 공지사항 체크.
     *
     * @param infoMap 서버 응답 데이터 Map (null이면 Error 반환)
     * @param lastSeenIndex 사용자가 마지막으로 본 공지 인덱스
     */
    fun checkNotice(infoMap: Map<String, Any?>?, lastSeenIndex: Int): NoticeCheckResult {
        if (infoMap == null) return NoticeCheckResult.Error
        val info = NoticeCheckInfo.fromMap(infoMap)
        return checkNotice(info, lastSeenIndex)
    }
}
