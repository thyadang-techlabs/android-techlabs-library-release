package com.techlabs.androidlib

import com.techlabs.androidlib.model.AppVersion

/**
 * 버전 비교 유틸리티.
 * Flutter 원본의 isMarketUpdateEnable() 로직을 그대로 이식한다.
 */
object VersionComparator {

    /**
     * x.y.z 문자열 버전 비교 (iOS용).
     * 서버 버전이 현재 버전보다 크면 true를 반환한다.
     *
     * Flutter 원본: isMarketUpdateEnable() in util.dart:1676
     */
    fun isUpdateRequired(serverVersion: String, currentVersion: String): Boolean {
        if (serverVersion.isBlank()) return false

        val server = AppVersion.fromString(serverVersion)
        val current = AppVersion.fromString(currentVersion)
        return server > current
    }

    /**
     * 빌드넘버(정수) 비교 (Android용).
     * 서버 빌드넘버가 현재 빌드넘버보다 크면 true를 반환한다.
     *
     * Flutter 원본: getAppVerChk()에서 currVer < maxVer 비교
     */
    fun isUpdateRequired(serverBuildNumber: Int, currentBuildNumber: Int): Boolean {
        return currentBuildNumber < serverBuildNumber
    }
}
