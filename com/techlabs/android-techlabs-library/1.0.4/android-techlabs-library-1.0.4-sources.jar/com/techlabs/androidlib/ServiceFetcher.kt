package com.techlabs.androidlib

import com.techlabs.androidlib.model.ServiceInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * 원격 서버(S3 등)에서 서비스 정보 JSON을 가져와 파싱하는 클래스.
 *
 * JSON 파일 포맷:
 * ```json
 * {
 *   "domain": "yeppo.net",
 *   "maintenance": "N",
 *   "message": "...",
 *   "title": "...",
 *   "appAction": "go-main",
 *   "appVerInfo": [ ... ]
 * }
 * ```
 *
 * @param connectTimeoutMs 연결 타임아웃 (밀리초, 기본 10초)
 * @param readTimeoutMs 읽기 타임아웃 (밀리초, 기본 10초)
 */
class ServiceFetcher(
    private val connectTimeoutMs: Int = 10_000,
    private val readTimeoutMs: Int = 10_000
) {

    /**
     * 원격 URL에서 JSON을 가져와 [ServiceInfo]로 파싱한다 (동기).
     *
     * 주의: 메인 스레드에서 호출하면 NetworkOnMainThreadException이 발생한다.
     *
     * @param url 서비스 정보 JSON 파일의 URL
     * @return 파싱된 [ServiceInfo]
     * @throws IOException 네트워크 오류 시
     * @throws org.json.JSONException JSON 파싱 실패 시
     */
    fun fetch(url: String): ServiceInfo {
        val json = fetchJsonFromUrl(url)
        return ServiceInfo.fromJsonString(json)
    }

    /**
     * [TechLabsLibrary.s3Url]에서 JSON을 가져와 [ServiceInfo]로 파싱한다 (동기).
     *
     * 주의: 메인 스레드에서 호출하면 NetworkOnMainThreadException이 발생한다.
     *
     * @return 파싱된 [ServiceInfo]
     * @throws IOException 네트워크 오류 시
     * @throws org.json.JSONException JSON 파싱 실패 시
     */
    fun fetch(): ServiceInfo {
        val url = TechLabsLibrary.s3Url
            ?: throw IllegalStateException("No S3 URL registered for appId '${TechLabsLibrary.appId}'. Check that the appId is supported.")
        return fetch(url)
    }

    /**
     * 원격 URL에서 JSON을 가져와 [ServiceInfo]로 파싱한다 (코루틴).
     *
     * IO 디스패처에서 실행되므로 메인 스레드에서 안전하게 호출할 수 있다.
     *
     * @param url 서비스 정보 JSON 파일의 URL
     * @return 파싱된 [ServiceInfo]
     * @throws IOException 네트워크 오류 시
     * @throws org.json.JSONException JSON 파싱 실패 시
     */
    suspend fun fetchSuspend(url: String): ServiceInfo {
        return withContext(Dispatchers.IO) {
            fetch(url)
        }
    }

    /**
     * [TechLabsLibrary.s3Url]에서 JSON을 가져와 [ServiceInfo]로 파싱한다 (코루틴).
     *
     * IO 디스패처에서 실행되므로 메인 스레드에서 안전하게 호출할 수 있다.
     *
     * @return 파싱된 [ServiceInfo]
     * @throws IOException 네트워크 오류 시
     * @throws org.json.JSONException JSON 파싱 실패 시
     */
    suspend fun fetchSuspend(): ServiceInfo {
        val url = TechLabsLibrary.s3Url
            ?: throw IllegalStateException("No S3 URL registered for appId '${TechLabsLibrary.appId}'. Check that the appId is supported.")
        return fetchSuspend(url)
    }

    /**
     * 원격 URL에서 JSON을 가져와 [ServiceInfo]로 파싱한다 (콜백).
     *
     * 백그라운드 스레드에서 실행되며, **콜백도 백그라운드 스레드에서 호출된다.**
     * UI 업데이트가 필요하면 콜백 내에서 메인 스레드로 전환해야 한다.
     *
     * @param url 서비스 정보 JSON 파일의 URL
     * @param callback 결과를 전달받을 콜백 (백그라운드 스레드에서 호출됨)
     */
    fun fetchAsync(url: String, callback: (Result<ServiceInfo>) -> Unit) {
        Thread {
            callback(runCatching { fetch(url) })
        }.start()
    }

    /**
     * [TechLabsLibrary.s3Url]에서 JSON을 가져와 [ServiceInfo]로 파싱한다 (콜백).
     *
     * 백그라운드 스레드에서 실행되며, **콜백도 백그라운드 스레드에서 호출된다.**
     * UI 업데이트가 필요하면 콜백 내에서 메인 스레드로 전환해야 한다.
     *
     * @param callback 결과를 전달받을 콜백 (백그라운드 스레드에서 호출됨)
     */
    fun fetchAsync(callback: (Result<ServiceInfo>) -> Unit) {
        val url = TechLabsLibrary.s3Url
            ?: return callback(Result.failure(IllegalStateException("No S3 URL registered for appId '${TechLabsLibrary.appId}'. Check that the appId is supported.")))
        fetchAsync(url, callback)
    }

    private fun fetchJsonFromUrl(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = connectTimeoutMs
            readTimeout = readTimeoutMs
        }

        try {
            val responseCode = connection.responseCode
            if (responseCode != HttpURLConnection.HTTP_OK) {
                throw IOException("HTTP $responseCode: ${connection.responseMessage}")
            }
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}
