package com.techlabs.androidlib.model

import org.json.JSONObject

/**
 * S3 서비스 정보 JSON의 appVerInfo 배열 항목 모델.
 *
 * @param device 디바이스 구분 ("ios" 또는 "android")
 * @param appName 앱 패키지명 (예: "techlabs.global.yeppo")
 * @param ver 서버 최소 필수 버전
 * @param type "0"=강제 업데이트, "1"=선택 업데이트
 * @param appName2 마켓 패키지명 (스토어 이동용)
 * @param latestVer 최신 버전 문자열
 */
data class AppVerInfo(
    val device: String,
    val appName: String,
    val ver: String,
    val type: String,
    val appName2: String,
    val latestVer: String
) {
    companion object {
        /**
         * [JSONObject]를 [AppVerInfo]로 변환한다.
         *
         * @param jsonObject appVerInfo 배열의 단일 항목 JSONObject
         * @throws org.json.JSONException JSON 파싱 실패 시
         */
        fun fromJsonObject(jsonObject: JSONObject): AppVerInfo {
            return AppVerInfo(
                device = jsonObject.optString("device", ""),
                appName = jsonObject.optString("app_name", ""),
                ver = jsonObject.optString("ver", ""),
                type = jsonObject.optString("type", "0"),
                appName2 = jsonObject.optString("app_name2", ""),
                latestVer = jsonObject.optString("latest_ver", "")
            )
        }
    }

    /**
     * [AppVerInfo]를 기존 [VersionCheckInfo]로 변환한다.
     */
    fun toVersionCheckInfo(): VersionCheckInfo {
        return VersionCheckInfo(
            ver = ver,
            latestVer = latestVer,
            type = type,
            appName2 = appName2
        )
    }
}
