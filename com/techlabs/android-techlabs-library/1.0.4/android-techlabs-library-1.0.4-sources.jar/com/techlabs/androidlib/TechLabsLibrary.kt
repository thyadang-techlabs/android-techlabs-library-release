package com.techlabs.androidlib

enum class ServerEnvironment {
    DEVELOPMENT,
    PRODUCTION
}

object TechLabsLibrary {

    @Volatile
    private var _appId: String? = null

    @Volatile
    private var _environment: ServerEnvironment? = null

    val appId: String
        get() = _appId ?: throw IllegalStateException("TechLabsLibrary is not initialized. Call init() first.")

    val s3Url: String?
        get() = synchronized(this) {
            val appId = _appId ?: throw IllegalStateException("TechLabsLibrary is not initialized. Call init() first.")
            val environment = _environment ?: throw IllegalStateException("TechLabsLibrary is not initialized. Call init() first.")
            getS3Url(appId, environment)
        }

    fun init(appId: String, environment: ServerEnvironment) {
        synchronized(this) {
            _appId = appId
            _environment = environment
        }
    }

    private fun getS3Url(appId: String, environment: ServerEnvironment): String? {
        return when (appId) {
            "techlabs.global.yeppo" -> when (environment) {
                ServerEnvironment.DEVELOPMENT -> "https://status.yeppo.net/dev-yeppo-service.json"
                ServerEnvironment.PRODUCTION -> "https://status.yeppo.net/www-yeppo-service.json"
            }
            else -> null
        }
    }
}
