package com.techlabs.androidlib

import com.techlabs.androidlib.model.VersionCheckInfo
import com.techlabs.androidlib.model.VersionCheckResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * 원격 서버(S3 등)에서 버전 정보 JSON을 가져와 버전 체크까지 수행하는 클래스.
 *
 * JSON 파일 포맷:
 * ```json
 * {
 *   "ver": "123",
 *   "latest_ver": "8.4.6",
 *   "type": "0",
 *   "app_name2": "com.example.app"
 * }
 * ```
 *
 * @param connectTimeoutMs 연결 타임아웃 (밀리초, 기본 10초)
 * @param readTimeoutMs 읽기 타임아웃 (밀리초, 기본 10초)
 */
class VersionCheckFetcher(
    private val connectTimeoutMs: Int = 10_000,
    private val readTimeoutMs: Int = 10_000
) {

    private val manager = VersionCheckManager()

    /**
     * 원격 URL에서 JSON을 가져와 [VersionCheckInfo]로 파싱한다 (동기).
     *
     * 주의: 메인 스레드에서 호출하면 NetworkOnMainThreadException이 발생한다.
     *
     * @param url 버전 정보 JSON 파일의 URL
     * @return 파싱된 [VersionCheckInfo]
     * @throws IOException 네트워크 오류 시
     * @throws org.json.JSONException JSON 파싱 실패 시
     */
    fun fetch(url: String): VersionCheckInfo {
        val json = fetchJsonFromUrl(url)
        return VersionCheckInfo.fromJsonString(json)
    }

    /**
     * 원격 URL에서 버전 정보를 가져와 Android 빌드넘버 기반 버전 체크를 수행한다 (동기).
     *
     * 주의: 메인 스레드에서 호출하면 NetworkOnMainThreadException이 발생한다.
     *
     * @param url 버전 정보 JSON 파일의 URL
     * @param currentBuildNumber 현재 앱의 빌드넘버
     * @return 버전 체크 결과. HTTP/파싱 실패 시 [VersionCheckResult.Error] 반환
     */
    fun checkFromRemote(url: String, currentBuildNumber: Int): VersionCheckResult {
        return try {
            val info = fetch(url)
            manager.checkVersion(info, currentBuildNumber)
        } catch (e: Exception) {
            VersionCheckResult.Error
        }
    }

    /**
     * 원격 URL에서 버전 정보를 가져와 iOS 문자열 버전 기반 버전 체크를 수행한다 (동기).
     *
     * 주의: 메인 스레드에서 호출하면 NetworkOnMainThreadException이 발생한다.
     *
     * @param url 버전 정보 JSON 파일의 URL
     * @param currentVersion 현재 앱의 버전 문자열 (예: "8.4.5")
     * @return 버전 체크 결과. HTTP/파싱 실패 시 [VersionCheckResult.Error] 반환
     */
    fun checkFromRemote(url: String, currentVersion: String): VersionCheckResult {
        return try {
            val info = fetch(url)
            manager.checkVersion(info, currentVersion)
        } catch (e: Exception) {
            VersionCheckResult.Error
        }
    }

    /**
     * 원격 URL에서 버전 정보를 가져와 Android 빌드넘버 기반 버전 체크를 수행한다 (코루틴).
     *
     * IO 디스패처에서 실행되므로 메인 스레드에서 안전하게 호출할 수 있다.
     *
     * @param url 버전 정보 JSON 파일의 URL
     * @param currentBuildNumber 현재 앱의 빌드넘버
     * @return 버전 체크 결과. HTTP/파싱 실패 시 [VersionCheckResult.Error] 반환
     */
    suspend fun checkFromRemoteSuspend(url: String, currentBuildNumber: Int): VersionCheckResult {
        return withContext(Dispatchers.IO) {
            checkFromRemote(url, currentBuildNumber)
        }
    }

    /**
     * 원격 URL에서 버전 정보를 가져와 iOS 문자열 버전 기반 버전 체크를 수행한다 (코루틴).
     *
     * IO 디스패처에서 실행되므로 메인 스레드에서 안전하게 호출할 수 있다.
     *
     * @param url 버전 정보 JSON 파일의 URL
     * @param currentVersion 현재 앱의 버전 문자열 (예: "8.4.5")
     * @return 버전 체크 결과. HTTP/파싱 실패 시 [VersionCheckResult.Error] 반환
     */
    suspend fun checkFromRemoteSuspend(url: String, currentVersion: String): VersionCheckResult {
        return withContext(Dispatchers.IO) {
            checkFromRemote(url, currentVersion)
        }
    }

    /**
     * 원격 URL에서 버전 정보를 가져와 Android 빌드넘버 기반 버전 체크를 수행한다 (콜백).
     *
     * 백그라운드 스레드에서 실행되며, **콜백도 백그라운드 스레드에서 호출된다.**
     * UI 업데이트가 필요하면 콜백 내에서 메인 스레드로 전환해야 한다.
     *
     * @param url 버전 정보 JSON 파일의 URL
     * @param currentBuildNumber 현재 앱의 빌드넘버
     * @param callback 결과를 전달받을 콜백 (백그라운드 스레드에서 호출됨)
     */
    fun checkFromRemoteAsync(
        url: String,
        currentBuildNumber: Int,
        callback: (VersionCheckResult) -> Unit
    ) {
        Thread {
            val result = checkFromRemote(url, currentBuildNumber)
            callback(result)
        }.start()
    }

    /**
     * 원격 URL에서 버전 정보를 가져와 iOS 문자열 버전 기반 버전 체크를 수행한다 (콜백).
     *
     * 백그라운드 스레드에서 실행되며, **콜백도 백그라운드 스레드에서 호출된다.**
     * UI 업데이트가 필요하면 콜백 내에서 메인 스레드로 전환해야 한다.
     *
     * @param url 버전 정보 JSON 파일의 URL
     * @param currentVersion 현재 앱의 버전 문자열 (예: "8.4.5")
     * @param callback 결과를 전달받을 콜백 (백그라운드 스레드에서 호출됨)
     */
    fun checkFromRemoteAsync(
        url: String,
        currentVersion: String,
        callback: (VersionCheckResult) -> Unit
    ) {
        Thread {
            val result = checkFromRemote(url, currentVersion)
            callback(result)
        }.start()
    }

    private fun fetchJsonFromUrl(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = connectTimeoutMs
            readTimeout = readTimeoutMs
        }

        try {
            val responseCode = connection.responseCode
            if (responseCode != HttpURLConnection.HTTP_OK) {
                throw IOException("HTTP $responseCode: ${connection.responseMessage}")
            }
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}
