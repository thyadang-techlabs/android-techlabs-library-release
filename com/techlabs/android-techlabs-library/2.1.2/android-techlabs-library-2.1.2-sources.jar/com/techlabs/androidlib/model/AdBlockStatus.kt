package com.techlabs.androidlib.model

enum class AdBlockStatus {
    NOT_BLOCKED,
    URL_BLOCKED,
    VPN_DETECTED,
    BOTH_DETECTED,
}
