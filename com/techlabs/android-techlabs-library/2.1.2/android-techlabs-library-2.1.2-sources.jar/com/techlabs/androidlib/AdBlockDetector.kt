package com.techlabs.androidlib

import android.util.Log
import com.techlabs.androidlib.model.AdBlockStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.NetworkInterface
import java.net.URL

/**
 * 광고 차단 환경(애드블로커, VPN 기반 차단 앱 등)을 탐지하는 유틸리티.
 * 네트워크 IO를 포함하므로 반드시 백그라운드 스레드 또는 suspend 컨텍스트에서 호출해야 한다.
 */
object AdBlockDetector {

    private const val TAG = "AdBlockDetector"

    @Volatile
    var curAdBlockStatus: AdBlockStatus = AdBlockStatus.NOT_BLOCKED
        private set

    /**
     * URL 차단이 확인된 경우에만 true.
     * VPN 단독은 false positive 가능성이 높아 차단으로 간주하지 않음.
     */
    val isBlocked: Boolean
        get() = curAdBlockStatus == AdBlockStatus.URL_BLOCKED || curAdBlockStatus == AdBlockStatus.BOTH_DETECTED

    private val adUrls = listOf(
        "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js",
        "https://googleads.g.doubleclick.net",
    )

    // 'utun'은 macOS/iOS 시스템 인터페이스로 존재할 수 있어 제외
    private val vpnInterfacePatterns = listOf("tun", "tap", "ppp", "ipsec")

    // ── suspend (병렬 처리) ──

    suspend fun detectAdBlockingSuspend(): AdBlockStatus {
        return withContext(Dispatchers.IO) {
            try {
                val (isUrlBlocked, isVpnConnected) = coroutineScope {
                    val urlDeferred = async { checkAdUrlBlocked() }
                    val vpnDeferred = async { checkVpnConnected() }
                    awaitAll(urlDeferred, vpnDeferred)
                }
                val status = when {
                    isUrlBlocked && isVpnConnected -> AdBlockStatus.BOTH_DETECTED
                    isUrlBlocked -> AdBlockStatus.URL_BLOCKED
                    isVpnConnected -> AdBlockStatus.VPN_DETECTED
                    else -> AdBlockStatus.NOT_BLOCKED
                }
                currentCoroutineContext().ensureActive()
                curAdBlockStatus = status
                status
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                curAdBlockStatus = AdBlockStatus.NOT_BLOCKED
                AdBlockStatus.NOT_BLOCKED
            }
        }
    }

    // ── sync ──

    /**
     * 메인 스레드 호출 금지 (네트워크 IO 포함, ANR 위험). suspend/async 버전 사용 권장.
     */
    fun detectAdBlocking(): AdBlockStatus {
        var urlResult = false
        var vpnResult = false
        val urlThread = Thread { urlResult = checkAdUrlBlocked() }
        val vpnThread = Thread { vpnResult = checkVpnConnected() }
        urlThread.start()
        vpnThread.start()
        return try {
            try {
                urlThread.join()
                vpnThread.join()
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
                urlThread.interrupt()
                vpnThread.interrupt()
                curAdBlockStatus = AdBlockStatus.NOT_BLOCKED
                return AdBlockStatus.NOT_BLOCKED
            }
            val status = when {
                urlResult && vpnResult -> AdBlockStatus.BOTH_DETECTED
                urlResult -> AdBlockStatus.URL_BLOCKED
                vpnResult -> AdBlockStatus.VPN_DETECTED
                else -> AdBlockStatus.NOT_BLOCKED
            }
            curAdBlockStatus = status
            status
        } catch (e: Exception) {
            curAdBlockStatus = AdBlockStatus.NOT_BLOCKED
            AdBlockStatus.NOT_BLOCKED
        }
    }

    // ── async (callback) ──

    /**
     * 콜백은 백그라운드 스레드에서 실행됨.
     */
    fun detectAdBlockingAsync(callback: (AdBlockStatus) -> Unit) {
        Thread {
            callback(detectAdBlocking())
        }.start()
    }

    // ── 주기적 감지 ──

    private val periodicScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var currentJob: Job? = null

    /** 주기적 감지가 현재 실행 중이면 true. */
    val isPeriodicDetectionRunning: Boolean
        get() = currentJob?.isActive == true

    /**
     * 즉시 1회 탐지 후 [intervalMs] 간격으로 반복 탐지를 시작한다.
     * 상태가 이전과 달라진 경우에만 [onStatusChanged]를 호출한다.
     * 콜백은 IO 디스패처(백그라운드 스레드)에서 호출되므로 UI 작업은 메인 디스패처로 전환할 것.
     * 라이프사이클과 분리되어 있어 명시적으로 [stopPeriodicDetection]을 호출하지 않으면 프로세스 종료까지 계속 실행됨.
     * 주기적 감지 시작 직후 첫 결과는 항상 콜백된다.
     * 이미 실행 중이면 무시된다.
     * 동일 상태에서 콜백 예외가 반복되면 첫 발생만 로깅된다.
     * @throws IllegalArgumentException [intervalMs]가 0 이하인 경우.
     */
    fun startPeriodicDetection(
        intervalMs: Long = 10_000L,
        onStatusChanged: ((AdBlockStatus) -> Unit)? = null,
    ) {
        require(intervalMs > 0L) { "intervalMs must be positive, was $intervalMs" }
        synchronized(this) {
            if (currentJob?.isActive == true) return
            currentJob = periodicScope.launch {
                var lastStatus: AdBlockStatus? = null
                var lastFailedStatus: AdBlockStatus? = null
                while (isActive) {
                    val status = detectAdBlockingSuspend()
                    if (onStatusChanged != null && status != lastStatus) {
                        try {
                            onStatusChanged(status)
                            lastStatus = status
                            lastFailedStatus = null
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            if (lastFailedStatus != status) {
                                Log.w(TAG, "onStatusChanged callback threw", e)
                                lastFailedStatus = status
                            }
                        }
                    } else if (onStatusChanged == null) {
                        lastStatus = status
                    }
                    delay(intervalMs)
                }
            }
        }
    }

    /**
     * 주기적 탐지를 중지한다. 실행 중이 아니면 무시된다.
     * 진행 중인 탐지는 코루틴 취소를 통해 즉시 중단된다.
     */
    fun stopPeriodicDetection() {
        synchronized(this) {
            currentJob?.cancel()
            currentJob = null
        }
    }

    // ── 내부 체크 ──

    private fun checkAdUrlBlocked(): Boolean {
        var blockedCount = 0
        for (url in adUrls) {
            try {
                val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                    requestMethod = "HEAD"
                    connectTimeout = 3_000
                    readTimeout = 3_000
                    instanceFollowRedirects = true
                }
                try {
                    val responseCode = connection.responseCode
                    if (responseCode !in 200..399) blockedCount++
                } finally {
                    connection.disconnect()
                }
            } catch (e: Exception) {
                blockedCount++
            }
        }
        // 모든 URL이 차단된 경우에만 true
        return blockedCount == adUrls.size
    }

    private fun checkVpnConnected(): Boolean {
        return try {
            NetworkInterface.getNetworkInterfaces()
                ?.asSequence()
                ?.filter { !it.isLoopback }
                ?.any { iface ->
                    val name = iface.name.lowercase()
                    vpnInterfacePatterns.any { name.startsWith(it) }
                } ?: false
        } catch (e: Exception) {
            false
        }
    }
}
