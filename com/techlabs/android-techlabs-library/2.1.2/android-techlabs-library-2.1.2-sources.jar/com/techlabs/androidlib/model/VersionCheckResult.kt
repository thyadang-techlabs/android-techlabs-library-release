package com.techlabs.androidlib.model

/**
 * 버전 체크 결과를 나타내는 sealed class.
 *
 * 각 결과는 Flutter 원본의 콜백코드와 대응된다:
 * - [ForceUpdate] → 콜백코드 1 (강제 업데이트)
 * - [OptionalUpdate] → 콜백코드 2 (선택 업데이트)
 * - [NoUpdateNeeded] → 콜백코드 0 (업데이트 불필요)
 * - [Error] → 콜백코드 3 (에러, info가 null인 경우)
 */
sealed class VersionCheckResult {

    /** 콜백코드 값 */
    abstract val callbackCode: Int

    /** 강제 업데이트 필요 (type="0") */
    data class ForceUpdate(val storePackage: String) : VersionCheckResult() {
        override val callbackCode: Int = 1
    }

    /** 선택 업데이트 가능 (type="1") */
    data class OptionalUpdate(val storePackage: String) : VersionCheckResult() {
        override val callbackCode: Int = 2
    }

    /** 업데이트 불필요 */
    data object NoUpdateNeeded : VersionCheckResult() {
        override val callbackCode: Int = 0
    }

    /** 에러 (info가 null인 경우 등) */
    data object Error : VersionCheckResult() {
        override val callbackCode: Int = 3
    }
}
