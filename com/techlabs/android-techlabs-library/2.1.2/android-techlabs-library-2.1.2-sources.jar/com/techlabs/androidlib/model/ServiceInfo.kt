package com.techlabs.androidlib.model

import org.json.JSONArray
import org.json.JSONObject

/**
 * S3 서비스 정보 JSON 최상위 모델.
 *
 * @param domain 서비스 도메인
 * @param maintenance 점검 여부 ("Y" 또는 "N")
 * @param message 점검 안내 메시지
 * @param title 점검 제목
 * @param appAction 앱 액션 값
 * @param appVerInfo 디바이스별 앱 버전 정보 목록
 */
data class ServiceInfo(
    val domain: String,
    val maintenance: String,
    val message: String,
    val title: String,
    val appAction: String,
    val appVerInfo: List<AppVerInfo>
) {
    /** 현재 서비스가 점검 중인지 여부. */
    val isUnderMaintenance: Boolean
        get() = maintenance == "Y"

    /** appVerInfo 목록에서 device == "android"인 첫 번째 항목. */
    val androidAppVerInfo: AppVerInfo?
        get() = appVerInfo.firstOrNull { it.device == "android" }

    companion object {
        /**
         * JSON 문자열을 [ServiceInfo]로 파싱한다.
         *
         * @param json S3에서 받아온 JSON 문자열
         * @throws org.json.JSONException JSON 파싱 실패 시
         */
        fun fromJsonString(json: String): ServiceInfo {
            val jsonObject = JSONObject(json)
            val appVerInfoArray: JSONArray = jsonObject.optJSONArray("appVerInfo") ?: JSONArray()
            val appVerInfoList = (0 until appVerInfoArray.length()).map { i ->
                AppVerInfo.fromJsonObject(appVerInfoArray.getJSONObject(i))
            }
            return ServiceInfo(
                domain = jsonObject.optString("domain", ""),
                maintenance = jsonObject.optString("maintenance", "N"),
                message = jsonObject.optString("message", ""),
                title = jsonObject.optString("title", ""),
                appAction = jsonObject.optString("appAction", ""),
                appVerInfo = appVerInfoList
            )
        }
    }
}
