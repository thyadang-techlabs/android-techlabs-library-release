package com.techlabs.androidlib.model

/**
 * 서버에서 내려온 버전 체크 응답 데이터 모델.
 *
 * @param ver 서버 최소 필수 버전 (Android: 빌드넘버 정수문자열, iOS: "x.y.z")
 * @param latestVer 최신 버전 문자열
 * @param type "0"=강제 업데이트, "1"=선택 업데이트
 * @param appName2 마켓 패키지명 (스토어 이동용)
 */
data class VersionCheckInfo(
    val ver: String,
    val latestVer: String,
    val type: String,
    val appName2: String
) {
    companion object {
        /**
         * Flutter MethodChannel 등에서 전달받은 Map을 [VersionCheckInfo]로 변환한다.
         */
        fun fromMap(map: Map<String, Any?>): VersionCheckInfo {
            return VersionCheckInfo(
                ver = (map["ver"] as? String) ?: "",
                latestVer = (map["latest_ver"] as? String) ?: "",
                type = (map["type"] as? String) ?: "",
                appName2 = (map["app_name2"] as? String) ?: ""
            )
        }

        /**
         * JSON 문자열을 [VersionCheckInfo]로 파싱한다.
         * 원격 서버(S3 등)에서 받아온 JSON 응답을 변환할 때 사용한다.
         *
         * @param json JSON 문자열 (예: `{"ver":"123","latest_ver":"8.4.6","type":"0","app_name2":"com.example.app"}`)
         * @throws org.json.JSONException JSON 파싱 실패 시
         */
        fun fromJsonString(json: String): VersionCheckInfo {
            val jsonObject = org.json.JSONObject(json)
            return VersionCheckInfo(
                ver = jsonObject.optString("ver", ""),
                latestVer = jsonObject.optString("latest_ver", ""),
                type = jsonObject.optString("type", ""),
                appName2 = jsonObject.optString("app_name2", "")
            )
        }
    }
}
