package com.techlabs.androidlib.model

/**
 * 서버에서 내려온 공지사항 체크 응답 데이터 모델.
 *
 * @param ntcLastIdx 서버의 최신 공지사항 인덱스 (문자열)
 */
data class NoticeCheckInfo(
    val ntcLastIdx: String
) {
    companion object {
        /**
         * Flutter MethodChannel 등에서 전달받은 Map을 [NoticeCheckInfo]로 변환한다.
         */
        fun fromMap(map: Map<String, Any?>): NoticeCheckInfo {
            return NoticeCheckInfo(
                ntcLastIdx = (map["ntc_last_idx"] as? String) ?: ""
            )
        }

        /**
         * JSON 문자열을 [NoticeCheckInfo]로 파싱한다.
         * 원격 서버(S3 등)에서 받아온 JSON 응답을 변환할 때 사용한다.
         *
         * @param json JSON 문자열 (예: `{"ntc_last_idx":"123"}`)
         * @throws org.json.JSONException JSON 파싱 실패 시
         */
        fun fromJsonString(json: String): NoticeCheckInfo {
            val jsonObject = org.json.JSONObject(json)
            return NoticeCheckInfo(
                ntcLastIdx = jsonObject.optString("ntc_last_idx", "")
            )
        }
    }
}
