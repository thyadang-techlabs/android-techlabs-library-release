package com.techlabs.androidlib.model

/**
 * 공지사항 체크 결과를 나타내는 sealed class.
 *
 * Flutter 원본의 checkNoticeNew() 로직과 대응된다:
 * - [HasNewNotice] → 서버 ntcLastIdx > 사용자가 마지막으로 본 인덱스
 * - [NoNewNotice] → 새 공지 없음
 * - [Error] → info가 null인 경우 등
 */
sealed class NoticeCheckResult {

    /** 새 공지사항이 있음 */
    data class HasNewNotice(val latestIndex: Int) : NoticeCheckResult()

    /** 새 공지사항 없음 */
    data object NoNewNotice : NoticeCheckResult()

    /** 에러 (info가 null인 경우 등) */
    data object Error : NoticeCheckResult()
}
