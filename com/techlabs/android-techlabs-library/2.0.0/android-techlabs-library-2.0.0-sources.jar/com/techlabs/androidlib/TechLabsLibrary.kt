package com.techlabs.androidlib

import com.techlabs.androidlib.model.ServiceInfo
import com.techlabs.androidlib.model.VersionCheckInfo
import com.techlabs.androidlib.model.VersionCheckResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

enum class ServerEnvironment {
    DEVELOPMENT,
    PRODUCTION
}

object TechLabsLibrary {

    @Volatile
    private var _appId: String? = null

    @Volatile
    private var _environment: ServerEnvironment? = null

    @Volatile
    private var _connectTimeoutMs: Int = 10_000

    @Volatile
    private var _readTimeoutMs: Int = 10_000

    @Volatile
    private var _serviceInfo: ServiceInfo? = null

    @Volatile
    private var _versionCheckInfo: VersionCheckInfo? = null

    private val manager = VersionCheckManager()

    // ── 초기화 ──

    fun init(
        appId: String,
        environment: ServerEnvironment,
        connectTimeoutMs: Int = 10_000,
        readTimeoutMs: Int = 10_000
    ) {
        synchronized(this) {
            val changed = _appId != appId || _environment != environment
            _appId = appId
            _environment = environment
            _connectTimeoutMs = connectTimeoutMs
            _readTimeoutMs = readTimeoutMs
            if (changed) {
                _serviceInfo = null
                _versionCheckInfo = null
            }
        }
    }

    val appId: String
        get() = _appId ?: throw IllegalStateException("TechLabsLibrary is not initialized. Call init() first.")

    val s3Url: String?
        get() = synchronized(this) {
            val appId = _appId ?: throw IllegalStateException("TechLabsLibrary is not initialized. Call init() first.")
            val environment = _environment ?: throw IllegalStateException("TechLabsLibrary is not initialized. Call init() first.")
            getS3Url(appId, environment)
        }

    // ── 응답 캐시 ──

    val serviceInfo: ServiceInfo?
        get() = _serviceInfo

    val versionCheckInfo: VersionCheckInfo?
        get() = _versionCheckInfo

    fun clearCache() {
        synchronized(this) {
            _serviceInfo = null
            _versionCheckInfo = null
        }
    }

    internal fun resetForTesting() {
        synchronized(this) {
            _appId = null
            _environment = null
            _connectTimeoutMs = 10_000
            _readTimeoutMs = 10_000
            _serviceInfo = null
            _versionCheckInfo = null
        }
    }

    // ── ServiceInfo 페치 ──

    fun fetchServiceInfo(url: String): ServiceInfo {
        val json = fetchJson(url)
        val info = ServiceInfo.fromJsonString(json)
        synchronized(this) { _serviceInfo = info }
        return info
    }

    fun fetchServiceInfo(): ServiceInfo {
        val url = s3Url
            ?: throw IllegalStateException("No S3 URL registered for appId '${appId}'. Check that the appId is supported.")
        return fetchServiceInfo(url)
    }

    suspend fun fetchServiceInfoSuspend(url: String): ServiceInfo {
        return withContext(Dispatchers.IO) { fetchServiceInfo(url) }
    }

    suspend fun fetchServiceInfoSuspend(): ServiceInfo {
        return withContext(Dispatchers.IO) { fetchServiceInfo() }
    }

    fun fetchServiceInfoAsync(url: String, callback: (Result<ServiceInfo>) -> Unit) {
        Thread {
            callback(runCatching { fetchServiceInfo(url) })
        }.start()
    }

    fun fetchServiceInfoAsync(callback: (Result<ServiceInfo>) -> Unit) {
        val url = try {
            s3Url ?: return callback(
                Result.failure(IllegalStateException("No S3 URL registered for appId '${appId}'. Check that the appId is supported."))
            )
        } catch (e: IllegalStateException) {
            return callback(Result.failure(e))
        }
        fetchServiceInfoAsync(url, callback)
    }

    // ── VersionCheckInfo 페치 ──

    fun fetchVersionCheckInfo(url: String): VersionCheckInfo {
        val json = fetchJson(url)
        val info = VersionCheckInfo.fromJsonString(json)
        synchronized(this) { _versionCheckInfo = info }
        return info
    }

    suspend fun fetchVersionCheckInfoSuspend(url: String): VersionCheckInfo {
        return withContext(Dispatchers.IO) { fetchVersionCheckInfo(url) }
    }

    fun fetchVersionCheckInfoAsync(url: String, callback: (Result<VersionCheckInfo>) -> Unit) {
        Thread {
            callback(runCatching { fetchVersionCheckInfo(url) })
        }.start()
    }

    // ── VersionCheck (페치 + 체크) ──

    fun checkVersionFromRemote(url: String, currentBuildNumber: Int): VersionCheckResult {
        return try {
            val info = fetchVersionCheckInfo(url)
            manager.checkVersion(info, currentBuildNumber)
        } catch (e: Exception) {
            VersionCheckResult.Error
        }
    }

    fun checkVersionFromRemote(url: String, currentVersion: String): VersionCheckResult {
        return try {
            val info = fetchVersionCheckInfo(url)
            manager.checkVersion(info, currentVersion)
        } catch (e: Exception) {
            VersionCheckResult.Error
        }
    }

    suspend fun checkVersionFromRemoteSuspend(url: String, currentBuildNumber: Int): VersionCheckResult {
        return withContext(Dispatchers.IO) { checkVersionFromRemote(url, currentBuildNumber) }
    }

    suspend fun checkVersionFromRemoteSuspend(url: String, currentVersion: String): VersionCheckResult {
        return withContext(Dispatchers.IO) { checkVersionFromRemote(url, currentVersion) }
    }

    fun checkVersionFromRemoteAsync(url: String, currentBuildNumber: Int, callback: (VersionCheckResult) -> Unit) {
        Thread {
            callback(checkVersionFromRemote(url, currentBuildNumber))
        }.start()
    }

    fun checkVersionFromRemoteAsync(url: String, currentVersion: String, callback: (VersionCheckResult) -> Unit) {
        Thread {
            callback(checkVersionFromRemote(url, currentVersion))
        }.start()
    }

    // ── 내부 HTTP ──

    private fun fetchJson(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = _connectTimeoutMs
            readTimeout = _readTimeoutMs
        }
        try {
            val responseCode = connection.responseCode
            if (responseCode != HttpURLConnection.HTTP_OK) {
                throw IOException("HTTP $responseCode: ${connection.responseMessage}")
            }
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private fun getS3Url(appId: String, environment: ServerEnvironment): String? {
        return when (appId) {
            "techlabs.global.yeppo" -> when (environment) {
                ServerEnvironment.DEVELOPMENT -> "https://status.yeppo.net/dev-yeppo-service.json"
                ServerEnvironment.PRODUCTION -> "https://status.yeppo.net/www-yeppo-service.json"
            }
            else -> null
        }
    }
}
